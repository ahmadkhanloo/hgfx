Author-review source, not cleared for submission.
Compile each .tex with pdfLaTeX twice in this flat directory.
The bibliography is rendered inline by citeproc; references.bib is supplied for editing.
Generic Pandoc article layout; no official Springer class is claimed.
Source and evidence documentation: paper/computational_statistics/ in the HGFX repository.
